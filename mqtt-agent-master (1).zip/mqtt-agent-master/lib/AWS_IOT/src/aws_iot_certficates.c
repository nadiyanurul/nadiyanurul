/*
 * Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * Additions Copyright 2016 Espressif Systems (Shanghai) PTE LTD
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

/**
 * @file aws_iot_certifcates.c
 * @brief File to store the AWS certificates in the form of arrays
 */

#ifdef __cplusplus
extern "C" {
#endif

const char aws_root_ca_pem[] = {"-----BEGIN CERTIFICATE-----\n"
                                "MIIDQTCCAimgAwIBAgITBmyfz5m/jAo54vB4ikPmljZbyjANBgkqhkiG9w0BAQsF\n"
                                "ADA5MQswCQYDVQQGEwJVUzEPMA0GA1UEChMGQW1hem9uMRkwFwYDVQQDExBBbWF6\n"
                                "b24gUm9vdCBDQSAxMB4XDTE1MDUyNjAwMDAwMFoXDTM4MDExNzAwMDAwMFowOTEL\n"
                                "MAkGA1UEBhMCVVMxDzANBgNVBAoTBkFtYXpvbjEZMBcGA1UEAxMQQW1hem9uIFJv\n"
                                "b3QgQ0EgMTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALJ4gHHKeNXj\n"
                                "ca9HgFB0fW7Y14h29Jlo91ghYPl0hAEvrAIthtOgQ3pOsqTQNroBvo3bSMgHFzZM\n"
                                "9O6II8c+6zf1tRn4SWiw3te5djgdYZ6k/oI2peVKVuRF4fn9tBb6dNqcmzU5L/qw\n"
                                "IFAGbHrQgLKm+a/sRxmPUDgH3KKHOVj4utWp+UhnMJbulHheb4mjUcAwhmahRWa6\n"
                                "VOujw5H5SNz/0egwLX0tdHA114gk957EWW67c4cX8jJGKLhD+rcdqsq08p8kDi1L\n"
                                "93FcXmn/6pUCyziKrlA4b9v7LWIbxcceVOF34GfID5yHI9Y/QCB/IIDEgEw+OyQm\n"
                                "jgSubJrIqg0CAwEAAaNCMEAwDwYDVR0TAQH/BAUwAwEB/zAOBgNVHQ8BAf8EBAMC\n"
                                "AYYwHQYDVR0OBBYEFIQYzIU07LwMlJQuCFmcx7IQTgoIMA0GCSqGSIb3DQEBCwUA\n"
                                "A4IBAQCY8jdaQZChGsV2USggNiMOruYou6r4lK5IpDB/G/wkjUu0yKGX9rbxenDI\n"
                                "U5PMCCjjmCXPI6T53iHTfIUJrU6adTrCC2qJeHZERxhlbI1Bjjt/msv0tadQ1wUs\n"
                                "N+gDS63pYaACbvXy8MWy7Vu33PqUXHeeE6V/Uq2V8viTO96LXFvKWlJbYK8U90vv\n"
                                "o/ufQJVtMVT8QtPHRh8jrdkPSHCa2XV4cdFyQzR1bldZwgJcJmApzyMZFo6IQ6XU\n"
                                "5MsI+yMRQ+hDKXJioaldXgjUkK642M4UwtBV8ob2xJNDd2ZhwLnoQdeXeGADbkpy\n"
                                "rqXRfboQnoZsG4q5WTP468SQvvG5\n"
                                "-----END CERTIFICATE-----"};

const char certificate_pem_crt[] = {"-----BEGIN CERTIFICATE-----\n"
                                    "MIIDWjCCAkKgAwIBAgIVANPB03R0WUKe1YatlgWMRYm9H53eMA0GCSqGSIb3DQEB\n"
                                    "CwUAME0xSzBJBgNVBAsMQkFtYXpvbiBXZWIgU2VydmljZXMgTz1BbWF6b24uY29t\n"
                                    "IEluYy4gTD1TZWF0dGxlIFNUPVdhc2hpbmd0b24gQz1VUzAeFw0yMTAyMTQxOTUz\n"
                                    "MzJaFw00OTEyMzEyMzU5NTlaMB4xHDAaBgNVBAMME0FXUyBJb1QgQ2VydGlmaWNh\n"
                                    "dGUwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDnSp2ChVK5+lBO9ZEv\n"
                                    "ujzyTKqL9kXuLFk95biBzKNYBKX1MfxTNsxxiDBzVVsImNkIkQuEFjTGpiJcEcCW\n"
                                    "7gKYsWRIx8tUg0ZK6k3HRR7YGrrpp3ScKss/cpprkcFY4DjmOS6J5eYgLbB5AgPu\n"
                                    "FQH29JvCI9aHElz9m8Vv8Ex3FX/+tjgA8sQNbxVGtq5n03M8b6TuyHOKsAFdvWpR\n"
                                    "YqZnQbJivzo6/donU2zikkOyWSH6e0ZlpU5te+gH3wAdr/hODoTI9Q7uF5Kjffvo\n"
                                    "99tzQva7mWcckGe+oez69pDYH+S147Nta2l4ZxojpzK3iiekPUlh3SepXoV3sIKU\n"
                                    "WOk7AgMBAAGjYDBeMB8GA1UdIwQYMBaAFI1wj6RhcZ7+VT9BpnBY1UFw+zNnMB0G\n"
                                    "A1UdDgQWBBSaCRoMGFZWLMBSKlrZs/ywGIdMoDAMBgNVHRMBAf8EAjAAMA4GA1Ud\n"
                                    "DwEB/wQEAwIHgDANBgkqhkiG9w0BAQsFAAOCAQEAj3JUjos3QyS0fAAkl/kchd4k\n"
                                    "mS+pCNVRRKDuv/Cm6ahtVTzF07CX8ybd/7ke9aMCrArbNYPaqc/MhiJOiL70Xx5g\n"
                                    "UrwV3mOaW1J7zpyR57nn3OuV2SerWALfTSuqOusI6ilGWVvGhKAo8RkR3ZFLvPWr\n"
                                    "jmpmnXFrA6FV7iB8Fo6Wca9j6IpFOA3/XgLRZg1F1poFtEnsttmmCf7qMwyDyxT2\n"
                                    "CH92UZJpEjsIlABNA22pogmJT6+TU/Fesr2gh2J/0PMat7oxCiQpFTdsAUm7Ka+X\n"
                                    "PuAr0UJMfGlPkMdFq6fHvWa7vRGmBKsNOFjAO5Skau2wJ5XMr2i/HCh6jDF27w==\n"
                                    "-----END CERTIFICATE-----"};

const char private_pem_key[] = {"-----BEGIN RSA PRIVATE KEY-----\n"
                                "MIIEowIBAAKCAQEA50qdgoVSufpQTvWRL7o88kyqi/ZF7ixZPeW4gcyjWASl9TH8\n"
                                "UzbMcYgwc1VbCJjZCJELhBY0xqYiXBHAlu4CmLFkSMfLVINGSupNx0Ue2Bq66ad0\n"
                                "nCrLP3Kaa5HBWOA45jkuieXmIC2weQID7hUB9vSbwiPWhxJc/ZvFb/BMdxV//rY4\n"
                                "APLEDW8VRrauZ9NzPG+k7shzirABXb1qUWKmZ0GyYr86Ov3aJ1Ns4pJDslkh+ntG\n"
                                "ZaVObXvoB98AHa/4Tg6EyPUO7heSo3376Pfbc0L2u5lnHJBnvqHs+vaQ2B/kteOz\n"
                                "bWtpeGcaI6cyt4onpD1JYd0nqV6Fd7CClFjpOwIDAQABAoIBABwxz1Oa1wPOzL1j\n"
                                "WAh+ZnGPAPdA1TN8eoB+IWjJPlw7bNOf/UdTlcZ9OJLGo+s/Xq2ZqNK4NkTE+clJ\n"
                                "bLW5W92rOjNZD6NEwWvedg7FkUX8tC5JeICVAuPAH6zfPreL1cPS0qaCvPPNPgby\n"
                                "RPJf4zZsiRQ4dC1RAr7znzTPETMu02m4+2y3wrm3cNpJICi4q2PTE877th3LqdDX\n"
                                "UZEdLS9nWnonQMNNVYmC+T3ywJXNNQyNqjx5mcMxtowSljK20wzxFDpWW4TvPEPV\n"
                                "kIEfmsLivOfusAptzmrO8pbxBzHRk5EBYO52oQAK73CiK2LlCONJBIKzMN5wiBuA\n"
                                "CjDqZ1kCgYEA+xEqw8RrW/b19y7MzkNYj7Uj4ukqxUyXE4YJAmK3rAcuoRol2HF9\n"
                                "VsIytALJ9VYYUjhW6UmQvmDytJBvFsBbKz5rFCFdgYkw8NprCs8Om98zsRVZ9t0a\n"
                                "85yvXdGSrc2OOby2T65cKtK80Rju590CLzcpg5bFlkZxhNIoSEsqDj8CgYEA69X6\n"
                                "zWy3nmMd/4AGgjnsSgWI2HueGBFe9TJSLYi+c4PqHngxdz0lWmIyCKqW6LscONao\n"
                                "zv1jKL7YjOiMY9wALiFKYlmDj7lYSS5vUGDSNl2yakEZBLx/56nuSNxN7q2d1Q+D\n"
                                "hq3uGKdE+oQE6LuQJgvsNGshMegvJ+594yjU3gUCgYAptwN8/YC9Cf56MHt09fmb\n"
                                "/wPUatthZsVfSBDtJYvQ+GyF9fs9yDWEGcYk5KW7rq9h0dyW7FMxXphU6f6bMCC1\n"
                                "waw27whDQpEwI4pPhHGv8lj7XknRW5Fj0q/MjcqqOBIeg71i5dyIfPVEZLklKzJ2\n"
                                "t9qc84sm2dN4txZcVKjLLwKBgQCGc4i34tpQJyvsBR4w0jr+/GbHHLrF9+lOGvE0\n"
                                "2nfRvYwU8Osqkqaf/8mMnUzJxBrT4LV+xIDqstscglu/dqZ3pi0VIvlZUA6gMiPu\n"
                                "DDTsH8DeyNwtkhXNili6Gzcm8r4/wMd4WeKbFYnC1M9Dq+MDfdqdC9Jx9HAl8Na+\n"
                                "UgIBzQKBgFM4umhEQR+3GGW34kFkSo9jk+YYUbgKp/SsBR0haYg1J0WGNYSnlgKh\n"
                                "L0CCWUF86l2c8Avxy9J3xRxi8pa5zXVB7bF2bVnztzZLLh8mzMB5O+aGxQtdHsxW\n"
                                "4zFWphY91gcdZP/sZ1VFNzTT/ch7g5mM+5fxeCsa7iwWtCKJ5khj\n"
                                "-----END RSA PRIVATE KEY-----"};


#ifdef __cplusplus
}
#endif
