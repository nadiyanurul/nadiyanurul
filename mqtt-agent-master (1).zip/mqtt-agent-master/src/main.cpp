#include <Arduino.h>
#include <AWS_IOT.h>
#include <WiFi.h>

#define DEVICE_ID 1001

AWS_IOT hornbill;

char WIFI_SSID[] = "kmr_bawah";
char WIFI_PASSWORD[] = "04011995";
char HOST_ADDRESS[] = "a3ed7zu3424fpb-ats.iot.us-west-2.amazonaws.com";
char CLIENT_ID[] = "enose_node_a";
char TOPIC[] = "telemetry/actuator";

uint8_t LEDpin = 2;
bool LEDstatus = LOW;

//message pattern : [0/1,ID]
int status = WL_IDLE_STATUS;
int tick = 0, msgCount = 0, msgReceived = 0;
char payload[512];
char incomingMsg[512];
char incomingID[512];

void mySubCallBackHandler(char *topicName, int payloadLen, char *payLoad) {
    strncpy(incomingMsg, payLoad, payloadLen);
    incomingMsg[payloadLen] = 0;
    msgReceived = 1;
}

//get device id from incoming message
int getDeviceID() {
    Serial.print("Received Message:");
    Serial.println(incomingMsg);
    for (int x = 2; x < strlen(incomingMsg); x++) {
        incomingID[x - 2] = incomingMsg[x];
    }

    return atoi(incomingID);
}

void setup() {
    pinMode(LEDpin, OUTPUT);
    Serial.begin(115200);
    delay(2000);

    while (status != WL_CONNECTED) {
        Serial.print("Attempting to connect to SSID: ");
        Serial.println(WIFI_SSID);
        // Connect to WPA/WPA2 network. Change this line if using open or WEP network:
        status = WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

        // wait 5 seconds for connection:
        delay(5000);
    }

    Serial.println("Connected to wifi");

    if (hornbill.connect(HOST_ADDRESS, CLIENT_ID) == 0) {
        Serial.println("Connected to AWS");
        delay(1000);

        if (0 == hornbill.subscribe(TOPIC, mySubCallBackHandler)) {
            Serial.println("Subscribe Successfull");
        } else {
            Serial.println("Subscribe Failed, Check the Thing Name and Certificates");
            while (1);
        }
    } else {
        Serial.println("AWS connection failed, Check the HOST Address");
        while (1);
    }

    delay(2000);

}

void loop() {
    if (msgReceived == 1) {
        if (getDeviceID() == DEVICE_ID) {
            digitalWrite(LEDpin, incomingMsg[0] == '1' ? HIGH : LOW);
        }
        msgReceived = 0;
    }
    vTaskDelay(1000 / portTICK_RATE_MS);
    tick++;
}